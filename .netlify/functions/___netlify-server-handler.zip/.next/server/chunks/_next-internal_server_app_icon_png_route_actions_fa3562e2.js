module.exports=[37083,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_icon_png_route_actions_fa3562e2.js.map