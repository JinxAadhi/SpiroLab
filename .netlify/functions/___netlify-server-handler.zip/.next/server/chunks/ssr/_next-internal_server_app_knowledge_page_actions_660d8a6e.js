module.exports=[54709,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_knowledge_page_actions_660d8a6e.js.map