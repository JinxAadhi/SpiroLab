var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/products/route.js")
R.c("server/chunks/[root-of-the-server]__af03cd36._.js")
R.c("server/chunks/_6ed1c089._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_products_route_actions_9a81c53e.js")
R.m(47974)
module.exports=R.m(47974).exports
