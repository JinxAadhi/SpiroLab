var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/products/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__ff5e218e._.js")
R.c("server/chunks/_6ed1c089._.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_api_products_[id]_route_actions_60052b14.js")
R.m(48527)
module.exports=R.m(48527).exports
