var R=require("../../chunks/[turbopack]_runtime.js")("server/app/icon.png/route.js")
R.c("server/chunks/[externals]_next_dist_a6d89067._.js")
R.c("server/chunks/node_modules_next_dist_esm_build_templates_app-route_97dac613.js")
R.c("server/chunks/[root-of-the-server]__f408c708._.js")
R.c("server/chunks/_next-internal_server_app_icon_png_route_actions_fa3562e2.js")
R.m(58338)
module.exports=R.m(58338).exports
